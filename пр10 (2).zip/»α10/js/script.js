let block_highslided,
		block,
		color_block,
		stop_highslide = false,
		played = false;

	function random(color)
	{
	
		if ( !color )
			return Math.floor(Math.random() * (6 - 0)) + 0;
			
		else
		{
		
			let c = Math.round( 255.0 * Math.random() );
	
			return 'rgb(' + c + ', ' + c + ', ' + c + ');';
			
		}
	
	}
	
	function highslide_block()
	{

		block_highslided = ( !block_highslided ) ? random() : block_highslided;
		color_block = ( block.children[ block_highslided ].attribute );
		block.children[ block_highslided ].setAttribute( 'style', 'background:' + random('c') );

		if ( stop_highslide == false )
			setTimeout("highslide_block()", 250);
		
		return;
	
	}
	
	document.addEventListener('DOMContentLoaded', function()
	{
	
		let timer = setTimeout("highslide_block()", 7000),
			music_buttons = document.getElementById('icons');
		
		block = document.getElementById('ulContent');
	
		document.body.onclick = function(e)
		{
	
			clearTimeout(timer);
	
		};
		
		block.onclick = function(e)
		{
		
			let has_style = e.target.parentElement.style.background || e.target.style.background;
			
			if ( has_style == '' )
				return;
				
			stop_highslide = true;
			let msie = navigator.userAgent.match(/MSIE ([0-9]{1,}[\.0-9]{0,})|Media Center PC/);
				
			if ( !msie )
			{

				let w_content;
					w_content = ( e.target.tagName == 'LI' ) ? e.target.innerHTML : e.target.parentElement.innerHTML;

				window.open("", "_blank", "width=400,height=400").document.write( w_content );

			}
			else
				alert('Этот браузер гадость...');

		};
		
		
	});